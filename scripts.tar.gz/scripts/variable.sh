#! /bin/bash

echo "we are extracting pid of  firewall"

shivansh=$(ps -aux |grep firewalld |awk 'FNR == 1 {print $2 }')

echo "the pid is $shivansh"

if [ "$shivansh" != "0" ]

    then
   echo "service is running"


else
   echo "service is not running"

fi



