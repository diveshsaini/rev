#! /bin/bash

echo "please enter the path in which you want to search the file "
read path

var=$(find $path -type f -name $1 |awk 'BEGIN{FS= "/"} FNR == 1{print $NF}')
echo $var

if [ "$var" == "$1" ]

then
echo  " $var file exixts"

else
echo "there is  no such file"

fi





