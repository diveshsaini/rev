#! /bin/bash
k=0

for (( d=0; d<=4; d++ ))
do
echo -e "\n"

   for (( f=0; f<=$k; f++))
   do

     echo  "*"

  done

let k++
done
