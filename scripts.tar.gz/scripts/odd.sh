#! /bin/bash

echo "This script will tell you the odd numbers"
echo "Please enter any number "
read number
echo -e "\n"

for(( d=1; d<=$number; d++ ))

do
  if(( $d %2 != 0 ))
  then
   echo  "$d"
  fi
  
done

 
