#! /bin/bash

echo "script for array"

one=(1 2 3 4 5)

echo ${one[2]}
