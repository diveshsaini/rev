#! /bin/bash


line=$(cat $1 |wc -l)


for ((d=1; d<=$line; d++))

do

echo "`awk 'BEGIN{FS=","} FNR == '$d'{print NR, $0}' $1`"



done

 

