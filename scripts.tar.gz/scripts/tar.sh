#! /bin/bash


item=$(find /home -type f -size +1M)


tar -cvzf file.tar.gz $item
