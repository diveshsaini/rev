#! /bin/bash
set -e


ls
wh
whereis mkdir
pwd




