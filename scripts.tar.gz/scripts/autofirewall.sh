#! /bin/bash

echo "this script will let you know about firewalld service"

shiv=$(systemctl status firewalld.service |awk 'FNR == 3 {print $2}')

pid=$(systemctl status firewalld.service |awk 'FNR == 4 {print $3}')

echo $shiv

if [ "$shiv" == "active" ]
then
echo "service is running with pid $pid"
elif [ "$shiv" == "inactive" ]
then
echo "service is not running"
else
echo "no output found"
fi


