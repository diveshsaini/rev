#! /bin/bash

echo "hello ! please enter the two numbers "
read first second
let "third = $first + $second"
echo "the output is $third"

