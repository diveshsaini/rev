#! /bin/bash

echo -e "\nthe two arguments are $1 and $2 "
