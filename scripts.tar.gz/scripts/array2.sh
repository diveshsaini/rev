#! /bin/bash
echo "please enter the number of goods/item which you want to display"
read value

k=1
f=1
h=0
s=0

for (( d=1; d<=$value; d++))
do

echo -e "please enter name of item no $k "
read item[h]
let k++
let h++

done

echo -e "\n"
for(( g=1; g<=$value; g++))
do

echo  -e "The name of item no $f is ${item[s]} "
let f++
let s++

done




