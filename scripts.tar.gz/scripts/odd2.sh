#! /bin/bash
k=1
for (( d=0; d<100; d++ ))

do

if(( $k %2 != 0 ))

then
echo $k
fi
let k++


done
